$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

# ASCII-only messages keep this script compatible with Windows PowerShell 5.1.
if (-not (Test-Path -LiteralPath '.\pkg\oxide_wasm.js')) {
    throw 'WebAssembly package not found. Run .\build.ps1 first.'
}

if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    throw 'Python launcher "py" was not found. Install Python 3 or start a local HTTP server manually.'
}

Write-Host 'Serving the project at http://localhost:8080 (press Ctrl+C to stop)...' -ForegroundColor Green
py -3 -m http.server 8080
