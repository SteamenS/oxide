/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const start: () => [number, number];
export const wasm_bindgen_eb646f4ce057c4f9___convert__closures_____invoke___f64______true_: (a: number, b: number, c: number) => void;
export const wasm_bindgen_eb646f4ce057c4f9___convert__closures_____invoke___web_sys_58f748c6b2be7105___features__gen_Event__Event______true_: (a: number, b: number, c: any) => void;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
