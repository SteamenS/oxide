# OXIDE — Rust Training System

Интерактивный практикум по Rust: 8 спринтов, теория, 48 задач и интерактивная модель владения памятью.

## Публикация на GitHub Pages

В репозитории открой **Settings → Pages** и выбери **Source: GitHub Actions**. Workflow `.github/workflows/deploy-pages.yml` автоматически публикует сайт при каждом push в `main` и поддерживает ручной запуск из Actions.

После успешного запуска адрес сайта: https://SteamenS.github.io/oxide/

## Структура

- `index.html` — интерфейс OXIDE v1.1.
- `pkg/` — скомпилированный Rust/WebAssembly-модуль.
- `src/lib.rs`, `Cargo.toml`, `rust-toolchain.toml` — исходный Rust-код и конфигурация сборки.
- `build.ps1` — локальная сборка WASM на Windows.
- `run.ps1` — локальный HTTP-сервер для проверки.

## Локальный запуск

В PowerShell из корня репозитория выполни `./run.ps1` и открой http://localhost:8080. Не запускай `index.html` напрямую через `file://`.
