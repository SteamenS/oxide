use std::cell::RefCell;

use wasm_bindgen::{closure::Closure, prelude::*, JsCast};
use web_sys::{window, Event, EventTarget, HtmlElement, KeyboardEvent, PointerEvent, Window};

const DRAG_SENSITIVITY: f64 = 0.72;
const MIN_DRAG_DISTANCE: f64 = 4.0;

#[derive(Clone, Copy)]
struct DragState {
    pointer_id: i32,
    last_x: f64,
    last_y: f64,
    start_x: f64,
    start_y: f64,
    moved: bool,
}

#[derive(Default)]
struct AppState {
    yaw_offset: f64,
    pitch_offset: f64,
    drag: Option<DragState>,
    suppress_next_click: bool,
    frame_pending: bool,
    last_yaw_label: i32,
    last_pitch_label: i32,
}

thread_local! {
    static STATE: RefCell<AppState> = RefCell::new(AppState::default());
    static STAGE: RefCell<Option<HtmlElement>> = const { RefCell::new(None) };
    static MANUAL_ROTOR: RefCell<Option<HtmlElement>> = const { RefCell::new(None) };
    static YAW_LABEL: RefCell<Option<HtmlElement>> = const { RefCell::new(None) };
    static PITCH_LABEL: RefCell<Option<HtmlElement>> = const { RefCell::new(None) };
    static LISTENERS: RefCell<Vec<Closure<dyn FnMut(Event)>>> = const { RefCell::new(Vec::new()) };
    static FRAME_CALLBACK: RefCell<Option<Closure<dyn FnMut(f64)>>> = const { RefCell::new(None) };
}

fn browser_window() -> Result<Window, JsValue> {
    window().ok_or_else(|| JsValue::from_str("Окно браузера недоступно"))
}

fn html_element_by_id(id: &str) -> Result<HtmlElement, JsValue> {
    let document = browser_window()?
        .document()
        .ok_or_else(|| JsValue::from_str("DOM document недоступен"))?;
    document
        .get_element_by_id(id)
        .ok_or_else(|| JsValue::from_str(&format!("Не найден элемент #{id}")))?
        .dyn_into::<HtmlElement>()
        .map_err(|_| JsValue::from_str(&format!("#{id} не является HTML-элементом")))
}

fn keep_listener(
    target: &EventTarget,
    name: &str,
    callback: Closure<dyn FnMut(Event)>,
    capture: bool,
) -> Result<(), JsValue> {
    target.add_event_listener_with_callback_and_bool(
        name,
        callback.as_ref().unchecked_ref(),
        capture,
    )?;
    LISTENERS.with(|items| items.borrow_mut().push(callback));
    Ok(())
}

fn queue_frame() {
    let should_schedule = STATE.with(|state| {
        let mut state = state.borrow_mut();
        if state.frame_pending {
            false
        } else {
            state.frame_pending = true;
            true
        }
    });
    if !should_schedule {
        return;
    }

    let Ok(win) = browser_window() else {
        STATE.with(|state| state.borrow_mut().frame_pending = false);
        return;
    };

    let scheduled = FRAME_CALLBACK.with(|slot| {
        let slot = slot.borrow();
        slot.as_ref()
            .and_then(|callback| win.request_animation_frame(callback.as_ref().unchecked_ref()).ok())
            .is_some()
    });
    if !scheduled {
        STATE.with(|state| state.borrow_mut().frame_pending = false);
    }
}

/// This function runs only after a real drag or keyboard command.
/// Scroll-linked rotation is updated by the page Rail module in a single rAF.
/// WASM is deliberately absent from the scroll path.
fn render_manual_rotation() {
    let (yaw, pitch) = STATE.with(|state| {
        let state = state.borrow();
        (state.yaw_offset, state.pitch_offset)
    });

    let yaw_label = yaw.round() as i32;
    let pitch_label = pitch.round() as i32;
    let transform = format!("rotateX({pitch:.2}deg) rotateY({yaw:.2}deg)");

    MANUAL_ROTOR.with(|slot| {
        if let Some(rotor) = slot.borrow().as_ref() {
            let _ = rotor.style().set_property("transform", &transform);
        }
    });

    let (update_yaw, update_pitch) = STATE.with(|state| {
        let mut state = state.borrow_mut();
        let update_yaw = state.last_yaw_label != yaw_label;
        let update_pitch = state.last_pitch_label != pitch_label;
        state.last_yaw_label = yaw_label;
        state.last_pitch_label = pitch_label;
        (update_yaw, update_pitch)
    });

    if update_yaw {
        YAW_LABEL.with(|slot| {
            if let Some(label) = slot.borrow().as_ref() {
                label.set_text_content(Some(&format!("{yaw_label}°")));
            }
        });
    }
    if update_pitch {
        PITCH_LABEL.with(|slot| {
            if let Some(label) = slot.borrow().as_ref() {
                label.set_text_content(Some(&format!("{pitch_label}°")));
            }
        });
    }
}

fn render_frame(_timestamp: f64) {
    STATE.with(|state| state.borrow_mut().frame_pending = false);
    render_manual_rotation();
}

fn update_manual_pitch(delta: f64) {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        state.pitch_offset = (state.pitch_offset + delta).clamp(-82.0, 82.0);
    });
}

fn begin_drag(event: &PointerEvent) {
    if event.button() != 0 {
        return;
    }
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if state.drag.is_some() {
            return;
        }
        let x = event.client_x() as f64;
        let y = event.client_y() as f64;
        state.drag = Some(DragState {
            pointer_id: event.pointer_id(),
            last_x: x,
            last_y: y,
            start_x: x,
            start_y: y,
            moved: false,
        });
        state.suppress_next_click = false;
    });
}

fn move_drag(event: &PointerEvent) {
    let pointer_id = event.pointer_id();
    let x = event.client_x() as f64;
    let y = event.client_y() as f64;

    let started = STATE.with(|state| {
        let mut state = state.borrow_mut();
        let Some(mut drag) = state.drag else {
            return None;
        };
        if drag.pointer_id != pointer_id {
            return None;
        }

        let dx = x - drag.last_x;
        let dy = y - drag.last_y;
        drag.last_x = x;
        drag.last_y = y;

        if !drag.moved && (x - drag.start_x).hypot(y - drag.start_y) < MIN_DRAG_DISTANCE {
            state.drag = Some(drag);
            return None;
        }

        let just_started = !drag.moved;
        drag.moved = true;
        state.yaw_offset += dx * DRAG_SENSITIVITY;
        state.pitch_offset = (state.pitch_offset - dy * DRAG_SENSITIVITY).clamp(-82.0, 82.0);
        state.drag = Some(drag);
        Some(just_started)
    });

    if let Some(just_started) = started {
        if just_started {
            STAGE.with(|slot| {
                if let Some(stage) = slot.borrow().as_ref() {
                    let _ = stage.class_list().add_1("dragging");
                    let _ = stage.set_pointer_capture(pointer_id);
                }
            });
        }
        event.prevent_default();
        queue_frame();
    }
}

fn finish_drag(pointer_id: i32, suppress_click: bool) {
    let moved = STATE.with(|state| {
        let mut state = state.borrow_mut();
        let Some(drag) = state.drag else {
            return false;
        };
        if drag.pointer_id != pointer_id {
            return false;
        }
        state.drag = None;
        if drag.moved && suppress_click {
            state.suppress_next_click = true;
        }
        drag.moved
    });

    STAGE.with(|slot| {
        if let Some(stage) = slot.borrow().as_ref() {
            let _ = stage.class_list().remove_1("dragging");
            if stage.has_pointer_capture(pointer_id) {
                let _ = stage.release_pointer_capture(pointer_id);
            }
        }
    });

    if moved {
        queue_frame();
    }
}

fn handle_keydown(event: &KeyboardEvent) {
    let step = if event.shift_key() { 14.0 } else { 7.0 };
    let handled = match event.key().as_str() {
        "ArrowLeft" => {
            STATE.with(|state| state.borrow_mut().yaw_offset -= step);
            true
        }
        "ArrowRight" => {
            STATE.with(|state| state.borrow_mut().yaw_offset += step);
            true
        }
        "ArrowUp" => {
            update_manual_pitch(-step);
            true
        }
        "ArrowDown" => {
            update_manual_pitch(step);
            true
        }
        "Enter" | " " => {
            if let Ok(document) = browser_window().and_then(|win| {
                win.document().ok_or_else(|| JsValue::from_str("DOM document недоступен"))
            }) {
                if let Ok(Some(selected)) = document.query_selector("#stage .blk.sel") {
                    if let Ok(button_like) = selected.dyn_into::<HtmlElement>() {
                        button_like.click();
                    }
                }
            }
            true
        }
        _ => false,
    };

    if handled {
        event.prevent_default();
        if matches!(event.key().as_str(), "ArrowLeft" | "ArrowRight" | "ArrowUp" | "ArrowDown") {
            queue_frame();
        }
    }
}

#[wasm_bindgen]
pub fn start() -> Result<(), JsValue> {
    let win = browser_window()?;
    let stage = html_element_by_id("stage")?;
    let manual_rotor = html_element_by_id("manual-rotor")?;

    STAGE.with(|slot| *slot.borrow_mut() = Some(stage.clone()));
    MANUAL_ROTOR.with(|slot| *slot.borrow_mut() = Some(manual_rotor));
    YAW_LABEL.with(|slot| *slot.borrow_mut() = html_element_by_id("core-yaw").ok());
    PITCH_LABEL.with(|slot| *slot.borrow_mut() = html_element_by_id("core-pitch").ok());

    let window_target: EventTarget = win.clone().unchecked_into();
    let stage_target: EventTarget = stage.clone().unchecked_into();

    // The page Rail module updates scroll-linked rotation.
    // The WASM module is intentionally absent from the scroll event path.
    let down_callback = Closure::<dyn FnMut(Event)>::new(|event: Event| {
        if let Some(pointer) = event.dyn_ref::<PointerEvent>() {
            begin_drag(pointer);
        }
    });
    keep_listener(&stage_target, "pointerdown", down_callback, false)?;

    let move_callback = Closure::<dyn FnMut(Event)>::new(|event: Event| {
        if let Some(pointer) = event.dyn_ref::<PointerEvent>() {
            move_drag(pointer);
        }
    });
    keep_listener(&stage_target, "pointermove", move_callback, false)?;

    let up_callback = Closure::<dyn FnMut(Event)>::new(|event: Event| {
        if let Some(pointer) = event.dyn_ref::<PointerEvent>() {
            finish_drag(pointer.pointer_id(), true);
        }
    });
    keep_listener(&window_target, "pointerup", up_callback, false)?;

    let cancel_callback = Closure::<dyn FnMut(Event)>::new(|event: Event| {
        if let Some(pointer) = event.dyn_ref::<PointerEvent>() {
            finish_drag(pointer.pointer_id(), false);
        }
    });
    keep_listener(&window_target, "pointercancel", cancel_callback, false)?;

    let lost_callback = Closure::<dyn FnMut(Event)>::new(|event: Event| {
        if let Some(pointer) = event.dyn_ref::<PointerEvent>() {
            finish_drag(pointer.pointer_id(), false);
        }
    });
    keep_listener(&stage_target, "lostpointercapture", lost_callback, false)?;

    let click_callback = Closure::<dyn FnMut(Event)>::new(|event: Event| {
        let suppress = STATE.with(|state| {
            let mut state = state.borrow_mut();
            let value = state.suppress_next_click;
            state.suppress_next_click = false;
            value
        });
        if suppress {
            event.prevent_default();
            event.stop_immediate_propagation();
        }
    });
    keep_listener(&stage_target, "click", click_callback, true)?;

    let key_callback = Closure::<dyn FnMut(Event)>::new(|event: Event| {
        if let Some(keyboard) = event.dyn_ref::<KeyboardEvent>() {
            handle_keydown(keyboard);
        }
    });
    keep_listener(&stage_target, "keydown", key_callback, false)?;

    let frame_callback = Closure::<dyn FnMut(f64)>::new(|timestamp| render_frame(timestamp));
    FRAME_CALLBACK.with(|slot| *slot.borrow_mut() = Some(frame_callback));
    render_manual_rotation();
    Ok(())
}
