# Windows PowerShell 5.1 / PowerShell 7 compatible build script.
# Always builds using the GNU host toolchain so Visual Studio / link.exe is not required.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

$BuildLog = Join-Path $PSScriptRoot 'build-log.txt'
if (Test-Path -LiteralPath $BuildLog) {
    Remove-Item -LiteralPath $BuildLog -Force
}
"OXIDE WASM BUILD LOG - $(Get-Date -Format s)" | Set-Content -LiteralPath $BuildLog -Encoding UTF8

$RustToolchain = 'stable-x86_64-pc-windows-gnu'

function Invoke-NativeCommand {
    param(
        [Parameter(Mandatory = $true)][string]$Command,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$FailureMessage
    )

    $previousPreference = $ErrorActionPreference
    try {
        # Windows PowerShell 5.1 may surface native stderr as non-terminating
        # NativeCommandError records. Process exit code is the source of truth.
        $ErrorActionPreference = 'Continue'
        Write-Host ("> {0} {1}" -f $Command, ($Arguments -join ' '))
        & $Command @Arguments 2>&1 | Tee-Object -FilePath $script:BuildLog -Append
        $nativeExitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $previousPreference
    }

    if ($nativeExitCode -ne 0) {
        throw ("{0} Exit code: {1}. Full output: {2}" -f $FailureMessage, $nativeExitCode, $script:BuildLog)
    }
}

if (-not (Get-Command rustup -ErrorAction SilentlyContinue)) {
    throw 'rustup was not found. Install Rust from https://rustup.rs/ and reopen PowerShell.'
}
if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) {
    throw 'cargo was not found. Reopen PowerShell after installing Rust.'
}

Write-Host '[1/3] Checking the GNU host toolchain...'
Invoke-NativeCommand -Command 'rustup' -Arguments @('toolchain', 'install', $RustToolchain, '--profile', 'minimal') -FailureMessage 'Could not install the GNU Rust toolchain.'
Invoke-NativeCommand -Command 'rustup' -Arguments @('target', 'add', 'wasm32-unknown-unknown', '--toolchain', $RustToolchain) -FailureMessage 'Could not install the WebAssembly target for GNU toolchain.'

if (-not (Get-Command wasm-pack -ErrorAction SilentlyContinue)) {
    Write-Host '[2/3] wasm-pack not found; installing with Cargo under GNU toolchain...'
    $previousToolchain = $env:RUSTUP_TOOLCHAIN
    try {
        $env:RUSTUP_TOOLCHAIN = $RustToolchain
        Invoke-NativeCommand -Command 'cargo' -Arguments @('install', 'wasm-pack', '--locked') -FailureMessage 'Could not install wasm-pack. See the build log.'
    }
    finally {
        if ($null -eq $previousToolchain) { Remove-Item Env:RUSTUP_TOOLCHAIN -ErrorAction SilentlyContinue }
        else { $env:RUSTUP_TOOLCHAIN = $previousToolchain }
    }
}
else {
    Write-Host '[2/3] wasm-pack is already installed.'
}

Write-Host '[3/3] Building the WebAssembly package with GNU host toolchain...'
$previousToolchain = $env:RUSTUP_TOOLCHAIN
try {
    # wasm-pack invokes Cargo/Rust through rustup shims. This explicit variable
    # makes the choice independent of any directory-specific rustup override.
    $env:RUSTUP_TOOLCHAIN = $RustToolchain
    Invoke-NativeCommand -Command 'wasm-pack' -Arguments @('build', '--target', 'web', '--release', '--out-dir', 'pkg') -FailureMessage 'wasm-pack build failed. See the build log.'
}
finally {
    if ($null -eq $previousToolchain) { Remove-Item Env:RUSTUP_TOOLCHAIN -ErrorAction SilentlyContinue }
    else { $env:RUSTUP_TOOLCHAIN = $previousToolchain }
}

Write-Host ''
Write-Host 'Build completed successfully.' -ForegroundColor Green
Write-Host 'Next, run .\run.ps1 and open http://localhost:8080'
Write-Host ("Full build log: {0}" -f $BuildLog)
